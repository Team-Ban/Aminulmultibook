package com.aminul.multibook

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Prototype multi-account browser shell.
 *
 * SECURITY/TECHNICAL NOTE:
 * Android WebView shares cookies/storage by default. This prototype gives each
 * saved account its own named tab but DOES NOT provide true isolated sessions.
 * Do not use it for sensitive multi-account use until per-profile isolation is
 * implemented and verified for the target Android version.
 */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var header: TextView
    private lateinit var accountStrip: HorizontalScrollView
    private lateinit var accountRow: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var prefs: SharedPreferences
    private val accounts = mutableListOf<Account>()
    private val webViews = mutableMapOf<String, WebView>()
    private var activeId: String? = null
    private var dark = false

    data class Account(val id: String, var name: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("multibook_settings", Context.MODE_PRIVATE)
        loadAccounts()
        buildUi()
        if (accounts.isEmpty()) addAccount("Facebook 1") else selectAccount(accounts.first().id)
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg())
        }
        header = TextView(this).apply {
            text = "Aminul MultiBook"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(fg())
            setPadding(18, 18, 18, 6)
        }
        root.addView(header)

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 4, 12, 8)
        }
        toolbar.addView(Button(this).apply {
            text = "+ Add account"
            setOnClickListener { askAccountName() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        toolbar.addView(Button(this).apply {
            text = if (dark) "Light" else "Dark"
            setOnClickListener {
                dark = !dark
                refreshTheme()
                (it as Button).text = if (dark) "Light" else "Dark"
            }
        })
        toolbar.addView(Button(this).apply {
            text = "Remove"
            setOnClickListener { removeActiveAccount() }
        })
        root.addView(toolbar)

        accountStrip = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        accountRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 0, 8, 8)
        }
        accountStrip.addView(accountRow)
        root.addView(accountStrip)

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        redrawAccounts()
    }

    private fun askAccountName() {
        val input = EditText(this).apply {
            hint = "e.g. Personal Facebook"
            setSingleLine(true)
        }
        AlertDialogBuilder(this, "Add browser tab", input) { name ->
            val clean = name.trim().ifBlank { "Facebook ${accounts.size + 1}" }
            addAccount(clean)
        }.show()
    }

    private fun addAccount(name: String) {
        val account = Account(java.util.UUID.randomUUID().toString(), name)
        accounts.add(account)
        saveAccounts()
        redrawAccounts()
        selectAccount(account.id)
    }

    private fun selectAccount(id: String) {
        activeId = id
        content.removeAllViews()
        val web = webViews.getOrPut(id) {
            WebView(this).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadsImagesAutomatically = true
                settings.userAgentString = settings.userAgentString
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                loadUrl("https://m.facebook.com/")
            }
        }
        if (web.parent != null) (web.parent as? ViewGroup)?.removeView(web)
        content.addView(web, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        redrawAccounts()
    }

    private fun removeActiveAccount() {
        val id = activeId ?: return
        val account = accounts.firstOrNull { it.id == id } ?: return
        android.app.AlertDialog.Builder(this)
            .setTitle("Remove ${account.name}?")
            .setMessage("This removes the tab from this app. Shared WebView cookies may remain.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Remove") { _, _ ->
                webViews.remove(id)?.apply {
                    stopLoading()
                    loadUrl("about:blank")
                    clearHistory()
                    removeAllViews()
                    destroy()
                }
                accounts.removeAll { it.id == id }
                saveAccounts()
                if (accounts.isEmpty()) addAccount("Facebook 1")
                else selectAccount(accounts.first().id)
                redrawAccounts()
            }.show()
    }

    private fun redrawAccounts() {
        if (!::accountRow.isInitialized) return
        accountRow.removeAllViews()
        accounts.forEach { account ->
            val b = Button(this).apply {
                text = if (account.id == activeId) "● ${account.name}" else account.name
                setOnClickListener { selectAccount(account.id) }
            }
            accountRow.addView(b)
        }
    }

    private fun refreshTheme() {
        root.setBackgroundColor(bg())
        header.setTextColor(fg())
        redrawAccounts()
    }

    private fun bg() = if (dark) Color.rgb(24, 25, 26) else Color.rgb(240, 242, 245)
    private fun fg() = if (dark) Color.WHITE else Color.rgb(28, 30, 33)

    private fun saveAccounts() {
        val arr = JSONArray()
        accounts.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name)) }
        prefs.edit().putString("accounts", arr.toString()).apply()
    }

    private fun loadAccounts() {
        val raw = prefs.getString("accounts", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                accounts.add(Account(o.getString("id"), o.getString("name")))
            }
        } catch (_: Exception) { accounts.clear() }
    }

    override fun onBackPressed() {
        val web = activeId?.let { webViews[it] }
        if (web?.canGoBack() == true) web.goBack() else super.onBackPressed()
    }
}

private class AlertDialogBuilder(
    private val activity: Activity,
    private val title: String,
    private val input: EditText,
    private val onSave: (String) -> Unit
) {
    fun show() {
        android.app.AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add") { _, _ -> onSave(input.text.toString()) }
            .show()
    }
}
