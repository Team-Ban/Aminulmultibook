# Aminul MultiBook — Android starter project

This is a starter Android Studio project for an account-tab browser shell that opens `https://m.facebook.com/`.

## Important limitation
This starter **does not truly isolate Facebook sessions**. Android WebView cookie/storage is shared by default, so separate tabs are not separate browser profiles. The UI can save multiple named tabs, but true account isolation must be implemented and tested with a supported profile/data-store architecture. Do not rely on this prototype to keep accounts separate.

## Build APK
1. Install Android Studio on a computer.
2. Open this folder in Android Studio.
3. Let Gradle sync finish (JDK 17 recommended).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

This is source code, not a prebuilt/tested APK. It requires an Android SDK and Gradle build environment.
